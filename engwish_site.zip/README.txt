
ENGWISH - Starter Website
=========================

Files:
- index.html
- about.html
- courses.html
- tutors.html
- contact.html
- styles.css
- assets/logo.png

Contact form:
------------
The contact form in contact.html currently uses a MAILTO fallback (it opens the visitor's email client to send the filled data to team.engwish@gmail.com).
This works without server setup but depends on the visitor having an email client configured.

To receive form submissions directly to team.engwish@gmail.com without relying on users' email clients, do one of the following:

Option A — Formspree (recommended, simple):
1. Go to https://formspree.io and sign up.
2. Create a new form and copy the form endpoint (it looks like: https://formspree.io/f/yourFormId).
3. In contact.html replace the form tag's action attribute:
   <form ... action="mailto:team.engwish@gmail.com" ...>
   with:
   <form ... action="https://formspree.io/f/yourFormId" method="POST">
4. Optionally add: <input type="hidden" name="_subject" value="New ENGWISH Consultation Request">
5. Formspree will forward submissions to your email (team.engwish@gmail.com) once verified.

Option B — Google Forms:
1. Create a Google Form with the same fields, then embed it (or link to it) from contact.html.

Option C — Use a backend:
1. If you have hosting with server-side capabilities, you can POST the form to your backend and send emails.

Deploying the site:
-------------------
- Netlify: drag-and-drop the unzipped folder or connect a GitHub repo.
- Vercel: import the project from GitHub or use the static folder.
- GitHub Pages: push to a repository and enable GitHub Pages.

If you'd like, I can:
- Configure the Formspree form and insert the endpoint into contact.html (I'll need the Formspree form ID).
- Zip the site for download (done here).
- Help you deploy to Netlify or GitHub Pages step-by-step.

